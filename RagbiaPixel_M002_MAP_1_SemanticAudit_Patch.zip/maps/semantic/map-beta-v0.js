(function (root, factory) {
  const data = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = data;
  if (root) root.RagbiaMapSemanticV0 = data;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  return {
  "schema": "ragbia-map-semantic-v0",
  "id": "map-beta-01",
  "status": "baseline-provisional",
  "sourceBaseline": "CORE V0.1",
  "units": "logical-pixel",
  "world": {
    "worldWidth": 4608,
    "worldHeight": 2688,
    "pixelScale": 4,
    "artWidth": 1152,
    "artHeight": 672,
    "chunkWidth": 1536,
    "chunkHeight": 1344,
    "chunkCols": 3,
    "chunkRows": 2
  },
  "seeds": {
    "grassNoise": 352854054,
    "roadNoise": 61477,
    "riverNoise": 76321,
    "treeClusters": 199503,
    "ambientDetails": 8877331
  },
  "gameplay": {
    "playerSpawnWorld": {
      "x": 720,
      "y": 1910
    },
    "slimeSpawnsWorld": [
      {
        "x": 1110,
        "y": 1700
      },
      {
        "x": 1460,
        "y": 1480
      },
      {
        "x": 2010,
        "y": 1780
      },
      {
        "x": 2460,
        "y": 1270
      },
      {
        "x": 2820,
        "y": 860
      },
      {
        "x": 3290,
        "y": 1650
      },
      {
        "x": 3690,
        "y": 1090
      },
      {
        "x": 4100,
        "y": 720
      }
    ]
  },
  "terrain": {
    "base": {
      "kind": "grass"
    },
    "road": {
      "kind": "dirt-road",
      "outer": [
        [
          0,
          538
        ],
        [
          130,
          500
        ],
        [
          234,
          454
        ],
        [
          356,
          420
        ],
        [
          486,
          392
        ],
        [
          614,
          326
        ],
        [
          719,
          255
        ],
        [
          818,
          190
        ],
        [
          902,
          127
        ],
        [
          874,
          81
        ],
        [
          787,
          148
        ],
        [
          690,
          209
        ],
        [
          588,
          275
        ],
        [
          470,
          338
        ],
        [
          350,
          367
        ],
        [
          215,
          405
        ],
        [
          104,
          449
        ],
        [
          0,
          475
        ]
      ],
      "inner": [
        [
          0,
          515
        ],
        [
          120,
          479
        ],
        [
          226,
          435
        ],
        [
          350,
          400
        ],
        [
          480,
          373
        ],
        [
          605,
          307
        ],
        [
          710,
          238
        ],
        [
          806,
          175
        ],
        [
          884,
          110
        ],
        [
          870,
          96
        ],
        [
          790,
          155
        ],
        [
          696,
          218
        ],
        [
          594,
          282
        ],
        [
          472,
          351
        ],
        [
          343,
          378
        ],
        [
          220,
          415
        ],
        [
          109,
          459
        ],
        [
          0,
          493
        ]
      ],
      "branchOuter": [
        [
          458,
          370
        ],
        [
          515,
          348
        ],
        [
          542,
          409
        ],
        [
          570,
          469
        ],
        [
          637,
          521
        ],
        [
          621,
          552
        ],
        [
          539,
          493
        ],
        [
          505,
          425
        ]
      ],
      "branchInner": [
        [
          476,
          367
        ],
        [
          505,
          360
        ],
        [
          529,
          415
        ],
        [
          557,
          465
        ],
        [
          629,
          519
        ],
        [
          619,
          535
        ],
        [
          552,
          477
        ],
        [
          522,
          418
        ]
      ]
    },
    "river": {
      "kind": "river",
      "bank": [
        [
          861,
          0
        ],
        [
          1024,
          0
        ],
        [
          1000,
          118
        ],
        [
          1036,
          205
        ],
        [
          1000,
          304
        ],
        [
          1046,
          383
        ],
        [
          1002,
          493
        ],
        [
          1068,
          575
        ],
        [
          1040,
          672
        ],
        [
          883,
          672
        ],
        [
          912,
          579
        ],
        [
          866,
          482
        ],
        [
          905,
          391
        ],
        [
          861,
          303
        ],
        [
          895,
          211
        ],
        [
          865,
          117
        ]
      ],
      "water": [
        [
          884,
          0
        ],
        [
          1001,
          0
        ],
        [
          978,
          119
        ],
        [
          1013,
          205
        ],
        [
          978,
          303
        ],
        [
          1024,
          383
        ],
        [
          980,
          493
        ],
        [
          1044,
          575
        ],
        [
          1015,
          672
        ],
        [
          910,
          672
        ],
        [
          938,
          579
        ],
        [
          892,
          482
        ],
        [
          930,
          391
        ],
        [
          887,
          303
        ],
        [
          921,
          211
        ],
        [
          892,
          117
        ]
      ],
      "inner": [
        [
          905,
          0
        ],
        [
          979,
          0
        ],
        [
          958,
          119
        ],
        [
          991,
          205
        ],
        [
          956,
          303
        ],
        [
          1001,
          383
        ],
        [
          958,
          493
        ],
        [
          1022,
          575
        ],
        [
          994,
          672
        ],
        [
          930,
          672
        ],
        [
          956,
          579
        ],
        [
          912,
          482
        ],
        [
          950,
          391
        ],
        [
          909,
          303
        ],
        [
          942,
          211
        ],
        [
          915,
          117
        ]
      ]
    },
    "bridge": {
      "id": "bridge-main",
      "kind": "wood-bridge",
      "x": 875,
      "y": 127,
      "w": 137,
      "h": 49
    }
  },
  "settlements": [
    {
      "id": "clareira-sul",
      "clearing": {
        "x": 178,
        "y": 478,
        "w": 206,
        "h": 134
      },
      "structures": [
        {
          "id": "casa-sul",
          "kind": "house",
          "x": 103,
          "y": 381,
          "w": 76,
          "h": 50,
          "variant": 0
        }
      ],
      "fences": [
        {
          "id": "cerca-sul-horizontal",
          "x": 81,
          "y": 453,
          "count": 10,
          "horizontal": true
        },
        {
          "id": "cerca-sul-vertical",
          "x": 81,
          "y": 453,
          "count": 5,
          "horizontal": false
        }
      ],
      "fields": [
        {
          "id": "campo-sul",
          "x": 133,
          "y": 454,
          "w": 70,
          "h": 42
        }
      ],
      "trees": [
        {
          "x": 74,
          "y": 414,
          "scale": 0.92,
          "variant": 2
        },
        {
          "x": 201,
          "y": 421,
          "scale": 0.82,
          "variant": 0
        }
      ]
    },
    {
      "id": "nucleo-beta",
      "clearing": {
        "x": 605,
        "y": 474,
        "w": 152,
        "h": 96
      },
      "structures": [
        {
          "id": "casa-nucleo-oeste",
          "kind": "house",
          "x": 555,
          "y": 418,
          "w": 68,
          "h": 47,
          "variant": 1
        },
        {
          "id": "casa-nucleo-leste",
          "kind": "house",
          "x": 646,
          "y": 441,
          "w": 59,
          "h": 43,
          "variant": 2
        },
        {
          "id": "casa-nucleo-sul",
          "kind": "house",
          "x": 577,
          "y": 522,
          "w": 63,
          "h": 44,
          "variant": 0
        }
      ],
      "fences": [
        {
          "id": "cerca-nucleo-horizontal",
          "x": 525,
          "y": 565,
          "count": 16,
          "horizontal": true
        },
        {
          "id": "cerca-nucleo-vertical",
          "x": 525,
          "y": 505,
          "count": 6,
          "horizontal": false
        }
      ],
      "fields": [
        {
          "id": "campo-nucleo",
          "x": 652,
          "y": 521,
          "w": 71,
          "h": 47
        }
      ],
      "trees": [
        {
          "x": 531,
          "y": 466,
          "scale": 0.83,
          "variant": 1
        },
        {
          "x": 724,
          "y": 493,
          "scale": 0.92,
          "variant": 0
        }
      ]
    }
  ],
  "landmarks": [
    {
      "id": "ruinas-norte",
      "kind": "ruins",
      "origin": {
        "x": 745,
        "y": 128
      },
      "collisionRects": [
        {
          "id": "ruina-topo",
          "x": 743,
          "y": 126,
          "w": 68,
          "h": 10
        },
        {
          "id": "ruina-esquerda",
          "x": 742,
          "y": 126,
          "w": 11,
          "h": 49
        },
        {
          "id": "ruina-direita",
          "x": 798,
          "y": 126,
          "w": 11,
          "h": 49
        },
        {
          "id": "ruina-coluna-a",
          "x": 755,
          "y": 139,
          "w": 15,
          "h": 36
        },
        {
          "id": "ruina-coluna-b",
          "x": 780,
          "y": 146,
          "w": 16,
          "h": 29
        },
        {
          "id": "ruina-fragmento",
          "x": 813,
          "y": 150,
          "w": 25,
          "h": 12
        }
      ],
      "physicalRocks": [
        {
          "id": "rock-ruin-a",
          "x": 733,
          "y": 172,
          "r": 7
        },
        {
          "id": "rock-ruin-b",
          "x": 840,
          "y": 172,
          "r": 6
        }
      ]
    }
  ],
  "vegetation": {
    "staticTrees": [
      [
        41,
        65,
        1.08,
        0
      ],
      [
        83,
        96,
        0.94,
        2
      ],
      [
        131,
        58,
        1.07,
        1
      ],
      [
        184,
        105,
        0.91,
        0
      ],
      [
        238,
        65,
        1.12,
        2
      ],
      [
        296,
        106,
        0.92,
        1
      ],
      [
        361,
        61,
        1.03,
        0
      ],
      [
        425,
        96,
        0.92,
        2
      ],
      [
        493,
        62,
        1.1,
        1
      ],
      [
        557,
        94,
        0.91,
        0
      ],
      [
        630,
        63,
        1.04,
        2
      ],
      [
        708,
        106,
        0.9,
        1
      ],
      [
        45,
        230,
        1.0,
        1
      ],
      [
        95,
        267,
        0.88,
        0
      ],
      [
        164,
        224,
        1.08,
        2
      ],
      [
        247,
        267,
        0.92,
        1
      ],
      [
        320,
        225,
        1.0,
        0
      ],
      [
        393,
        260,
        0.87,
        2
      ],
      [
        766,
        70,
        0.96,
        2
      ],
      [
        815,
        60,
        0.88,
        0
      ],
      [
        1072,
        78,
        1.08,
        1
      ],
      [
        1118,
        128,
        0.94,
        0
      ],
      [
        1085,
        220,
        1.06,
        2
      ],
      [
        1120,
        293,
        0.9,
        1
      ],
      [
        53,
        615,
        1.1,
        0
      ],
      [
        133,
        580,
        0.92,
        2
      ],
      [
        229,
        616,
        1.06,
        1
      ],
      [
        334,
        591,
        0.9,
        0
      ],
      [
        411,
        631,
        1.08,
        2
      ],
      [
        744,
        596,
        0.98,
        1
      ],
      [
        809,
        631,
        1.08,
        0
      ],
      [
        869,
        572,
        0.91,
        2
      ],
      [
        1096,
        612,
        1.09,
        1
      ]
    ],
    "clusters": [
      {
        "cx": 120,
        "cy": 160,
        "rx": 95,
        "ry": 45,
        "count": 13
      },
      {
        "cx": 292,
        "cy": 150,
        "rx": 105,
        "ry": 38,
        "count": 13
      },
      {
        "cx": 505,
        "cy": 180,
        "rx": 80,
        "ry": 34,
        "count": 10
      },
      {
        "cx": 1084,
        "cy": 380,
        "rx": 58,
        "ry": 90,
        "count": 12
      },
      {
        "cx": 795,
        "cy": 540,
        "rx": 75,
        "ry": 45,
        "count": 10
      },
      {
        "cx": 370,
        "cy": 550,
        "rx": 65,
        "ry": 36,
        "count": 8
      }
    ],
    "flowerSpots": [
      [
        250,
        310
      ],
      [
        420,
        305
      ],
      [
        330,
        470
      ],
      [
        155,
        542
      ],
      [
        695,
        355
      ],
      [
        777,
        466
      ],
      [
        1040,
        335
      ],
      [
        839,
        252
      ]
    ]
  },
  "collision": {
    "playerRadiusWorld": 20,
    "playerFootOffsetYWorld": 28,
    "entityDefaultRadiusWorld": 30,
    "entityDefaultOffsetYWorld": 22,
    "buildingFootprints": [
      {
        "id": "casa-sul",
        "x": 97,
        "y": 376,
        "w": 88,
        "h": 60
      },
      {
        "id": "casa-nucleo-oeste",
        "x": 550,
        "y": 413,
        "w": 80,
        "h": 59
      },
      {
        "id": "casa-nucleo-leste",
        "x": 640,
        "y": 436,
        "w": 72,
        "h": 54
      },
      {
        "id": "casa-nucleo-sul",
        "x": 571,
        "y": 517,
        "w": 75,
        "h": 55
      }
    ],
    "fenceFootprints": [
      {
        "id": "cerca-sul-horizontal",
        "x": 80,
        "y": 449,
        "w": 112,
        "h": 8
      },
      {
        "id": "cerca-sul-vertical",
        "x": 77,
        "y": 450,
        "w": 8,
        "h": 58
      },
      {
        "id": "cerca-nucleo-horizontal",
        "x": 523,
        "y": 561,
        "w": 188,
        "h": 8
      },
      {
        "id": "cerca-nucleo-vertical",
        "x": 521,
        "y": 503,
        "w": 8,
        "h": 66
      }
    ],
    "waterPolygons": [
      {
        "id": "rio-norte",
        "points": [
          [
            884,
            0
          ],
          [
            1001,
            0
          ],
          [
            978,
            119
          ],
          [
            1009,
            126
          ],
          [
            1009,
            126
          ],
          [
            878,
            126
          ],
          [
            892,
            117
          ]
        ]
      },
      {
        "id": "rio-sul",
        "points": [
          [
            897,
            176
          ],
          [
            1008,
            176
          ],
          [
            978,
            205
          ],
          [
            978,
            303
          ],
          [
            1024,
            383
          ],
          [
            980,
            493
          ],
          [
            1044,
            575
          ],
          [
            1015,
            672
          ],
          [
            910,
            672
          ],
          [
            938,
            579
          ],
          [
            892,
            482
          ],
          [
            930,
            391
          ],
          [
            887,
            303
          ],
          [
            921,
            211
          ]
        ]
      }
    ]
  },
  "regions": [
    {
      "name": "Clareira Sul",
      "when": "x < 1350 && y > 1400"
    },
    {
      "name": "Núcleo Beta",
      "when": "x > 1900 && x < 3000 && y > 1500"
    },
    {
      "name": "Margem do Rio",
      "when": "x > 3380 && x < 4260"
    },
    {
      "name": "Ruínas do Norte",
      "when": "x > 2750 && y < 900"
    },
    {
      "name": "Campos do Norte",
      "when": "y < 1050"
    },
    {
      "name": "Estrada Central",
      "when": "fallback"
    }
  ]
};
});
